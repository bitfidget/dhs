import React from 'react';
import Horizon from './components/Horizon.jsx';

React.render(<Horizon className="horizon"  width="1024" height="768"/>, document.getElementById('main'));
