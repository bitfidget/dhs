var gulp = require('gulp');
gulp.task('default', ['build', 'watch', 'server']);